#include "../bor-util.h"

int main(int argc, const char *argv[])
{
    if (argc != 2) {
        fprintf(stderr, "Un argument requis !\n");
    }
    uint32_t path = atoi(argv[1]);
    struct sockaddr_in addr;
    int soc = bor_create_socket_in(SOCK_STREAM, 0, &addr);
    if (soc < 0) {
       exit(1); 
    }
    struct sockaddr_in addr_serv;
    bor_resolve_address_in(argv[1], 13, &addr_serv);
    int k = bor_connect_in(soc, &addr_serv);
    if (k < 0) {
        close(soc);
        exit(1);
    }
    char buf[1000];
    k = bor_read_str(soc, buf, sizeof(buf));
    if (k < 0) {
        close(soc);
        exit(1);
    }
    printf("%s\n", buf);
    close(soc);
    return 0;
}
