#include "../bor-util.h"
#include "strings.h"

int boucle = 1;
char buf[1000];

int couper_ligne(int debut, int fin)
{
    int i;
    for (i = debut; i < fin; i++) {
        if (buf[i] == '\n') {
            buf[i] = '\0';
            return i;
        }
    }
    return -1;
}

void suppression_ligne(int index, int *fin)
{
    memmove(buf, buf + index + 1, *fin - (index + 1) + 1);
    *fin -= index + 1;
}

int defragmenter_ligne(int *pos, int fin)
{
     int debut = *pos;
     int i = *pos;
     while ((i = couper_ligne(debut, fin)) >= 0) {
        printf("Une ligne détectée : \"%s\"\n", buf);
        suppression_ligne(i, &fin);
        debut = 0;
     }
     printf("Reste dans buf : \"%s\"\n", buf);
     *pos = fin;
     if (*pos >= 1000 - 1) {
        printf("Dépassement capacité\n");
        *pos = 0;
        buf[0] = '\0';
     }
}

int lire_ligne(int soc)
{
    int k;
    int pos = 0;
    while (1) {
        k = bor_read_str(soc, buf + pos, sizeof(buf) - pos);
        if (k <= 0) {
            return k;
        }
        pos += k;
        defragmenter_ligne(&pos, pos + k);
    }
}

int main(int argc, const char *argv[])
{
    if (argc != 3) {
        fprintf(stderr, "Deux argument requis !\n");
    }
    const char* path = argv[1];
    int port = atoi(argv[2]);
    struct sockaddr_in addr;
    int soc = bor_create_socket_in(SOCK_STREAM, 0, &addr);
    if (soc < 0) {
       exit(1); 
    }
    struct sockaddr_in addr_serv;
    bor_resolve_address_in(path, port, &addr_serv);    
    int k = bor_connect_in(soc, &addr_serv);
    if (k < 0) {
        close(soc);
        exit(1);
    }
    while (boucle) {
        k = lire_ligne(soc);
        if (k <= 0) {
            break;
        }
    }
    close(soc);
    return 0;
}
